# Welcome

![](.gitbook/assets/developers.png)

### Get Started

Autocredit is an easy way to accept payments and make instant payouts in Africa.   
  
The Autocredit API helps you create your own payments flow—from e-commerce to recurring payments, payouts and everything in between.  
  
To start integrating the Autocredit API, read our Developer Introduction.

If you are not a developer, try using our community built plugins and libraries - no code required.

{% page-ref page="fundamentals/community-libraries.md" %}

